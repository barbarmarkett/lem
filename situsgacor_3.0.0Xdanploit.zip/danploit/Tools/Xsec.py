import re
import os
try:
    import requests
except Exception as e:
    print('Modul requests belum diinstall!\nAuto install diaktifkan :D')
    os.system('pip install requests')
    
def Extract(url):
    try:
        response = requests.get(url)
    except Exception as e:
        print('Web zone-xsec.com sedang down :(')
        
    domains = []
    preg = re.findall(r'<td>([a-zA-Z0-9.-]+)</td>', response.text)
     
    for domain in preg:
        if re.match(r'[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}', domain):
            domain = (
                    domain.replace("c...", "com")
                    .replace("co...", "com")
                    .replace("go...", "go.id")
                    .replace("i...", "id")
                    .replace("ac....", "ac.id")
                    .replace("com.", "com")
                    .replace("com..", "com")
                    .replace("ac.id...", "ac.id")
                    .replace("go.id.", "go.id")
                    .replace("go.id...", "go.id")
                    .replace("go.id..", "go.id")
                    .replace("g...", "go.id")
                    .replace("...", "")
                    .replace("or.", "or.id")
                    .replace("or.idid", "or.id")
                    .replace("or.idi", "or.id")
                )
            domains.append(domain)
    return domains
   