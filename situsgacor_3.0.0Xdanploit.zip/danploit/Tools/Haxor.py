import re
import os
try:
    import requests
except Exception as e:
    print('Modul requests belum diinstall!\nAuto install diaktifkan :D')
    os.system('pip install requests')
    
def Extract(url):
    try:
        response = requests.get(url)
    except Exception as e:
        print('Kemungkinan Web haxor.id sedang down :(')
            
    html_content = response.text
    pattern = re.compile(r'href=["\'](https?://.*?)["\']')
    matches = pattern.findall(html_content)

    extracted_urls = []
    if matches:
        for href_value in matches:
            href_value = re.sub(r'^https?://', '', href_value)
            href_value = re.sub(r'/.*', '', href_value)
            extracted_urls.append(href_value)
    return extracted_urls       